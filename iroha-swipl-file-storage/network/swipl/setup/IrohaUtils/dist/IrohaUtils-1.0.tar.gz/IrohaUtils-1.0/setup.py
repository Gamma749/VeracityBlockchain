from distutils.core import setup
setup(name='IrohaUtils',
      version='1.0',
      py_modules=['IrohaUtils'],
      )